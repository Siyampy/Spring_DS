package com;

public class Contact {
	private int mobile;
	private int alternateMobile;
	private int landline;
	private String email;
	private Address address;
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public int getAlternateMobile() {
		return alternateMobile;
	}
	public void setAlternateMobile(int alternateMobile) {
		this.alternateMobile = alternateMobile;
	}
	public int getLandline() {
		return landline;
	}
	public void setLandline(int landline) {
		this.landline = landline;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	

}
