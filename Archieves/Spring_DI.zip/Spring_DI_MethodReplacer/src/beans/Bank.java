package beans;

public class Bank 
{
	public void deposit() {
		System.out.println("Deposit method");
	}
	public void withdraw()
	{
		System.out.println("Withdraw method");
	}
	public void CalInt()
	{
		System.out.println("CalInt method");
	}

}
