package beans;

public class Test2 { 
	public void init()
	{
		System.out.println("TEst 2 init");
	}
	public void destroy()
	{
		System.out.println("TEst 2 destroy");

	}

}
