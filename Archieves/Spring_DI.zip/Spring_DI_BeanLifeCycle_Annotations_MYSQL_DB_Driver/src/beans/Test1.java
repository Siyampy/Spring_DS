package beans;

public class Test1 { 
	public void init()
	{
		System.out.println("TEst 1 init");
	}
	public void destroy()
	{
		System.out.println("TEst 1 destroy");

	}

}
