package beans;

public class C {
	public C()
	{
		System.out.println("C created");
	}

}
