package beans;

public class A {
	public A()
	{
		System.out.println("A created");
	}
	public void info()
	{
		System.out.println("Information:A");
	}

}
