package beans;

public class B {
	public B()
	{
		System.out.println("B created");
	}

}
