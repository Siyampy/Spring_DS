package beans;

public class Amaze implements Car{

	@Override
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println(" Safe Drive than other cars");
	}
	

}
