package beans;

public class Audi implements Car{
	@Override
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println(" Most Safe Drive than other cars");
	}

}
