package beans;

public interface Car 
{
	public Engine myCarEngine();

}
