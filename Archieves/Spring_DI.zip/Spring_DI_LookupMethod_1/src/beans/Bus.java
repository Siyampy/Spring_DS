package beans;

public abstract class Bus
{
	abstract public Engine myBusEngine();
	

}
