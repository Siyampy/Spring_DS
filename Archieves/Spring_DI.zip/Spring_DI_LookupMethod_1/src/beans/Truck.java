package beans;

public class Truck {
	public Engine myTruckEngine() {
		Engine e=new Engine();
		e.setName("Eicher");
		return e;
	}

}
