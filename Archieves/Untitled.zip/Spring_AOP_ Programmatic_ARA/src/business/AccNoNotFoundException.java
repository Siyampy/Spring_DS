package business;

public class AccNoNotFoundException extends RuntimeException{
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Account Number Invalid";
	}

}
